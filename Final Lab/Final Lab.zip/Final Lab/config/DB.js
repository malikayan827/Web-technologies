const mongoose = require("mongoose");

const connectDB = async () => {
  const conn = await mongoose.connect(
    "mongodb+srv://ayan:ayan@cluster0.j5bluef.mongodb.net/"
  );

  console.log(`MongoDB Connected`);
};

module.exports = connectDB;
