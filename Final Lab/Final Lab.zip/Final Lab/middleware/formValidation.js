function validateForm(req, res, next) {
    const { name, price, description, category } = req.body;
    console.log(req.body);

  if (!name || !price || !description || !category) {
    return res.redirect("/error");
  }
  

  next();
}

module.exports = validateForm;
