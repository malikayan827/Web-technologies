const mongoose=require('mongoose');
const productSchema=new mongoose.Schema({
    name:{
        type:String,
        
        trim:true,
        
    }
    ,
    description:{
        type:String,
        
    },
    price:{
        type:Number,
       
        maxLength:[8,"Price cannot exceed 8 characters"]
    },
    ratings:{
        type:Number,
        default:0
    },
    
    category:{
        type:String,
        required:[true,"Please enter product category"]

    },
    stock:{
        type:Number,
        required:[true,"Please enter product stock"],
        maxLength:[4,"Stock cannot exceed 4 characters"],
        default:1
    },
    numOfReviews:{
        type:Number,
        default:0
    },
    
    
    
    createdAt:{
        type:Date,
        default:Date.now
     
    }


})
module.exports =  mongoose.model('Product',productSchema);