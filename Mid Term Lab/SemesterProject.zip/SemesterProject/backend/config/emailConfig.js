exports.ENV = {
    EMAIL : 'appecom865@gmail.com',
    PASSWORD:"ecomapp867"
}

