// searchActions.js

export const setSearchTerm = (term) => ({
    type: 'SET_SEARCH_TERM',
    payload: term,
  });
  